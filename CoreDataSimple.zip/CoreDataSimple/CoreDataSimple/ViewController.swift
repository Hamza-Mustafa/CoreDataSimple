//
//  ViewController.swift
//  CoreDataSimple
//
//  Created by Mohammad Shuja on 09/11/2021.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var createBt: UIButton!
    @IBOutlet weak var retrieveBt: UIButton!
    @IBOutlet weak var updateBt: UIButton!
    @IBOutlet weak var deleteBt: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func createPressed(_ sender: Any) {
       
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let userEntity = NSEntityDescription.entity(forEntityName: "Users", in: managedContext)!
       
        
        for i in 1...5 {
            let user = NSManagedObject(entity: userEntity, insertInto: managedContext)
            user.setValue("Hamza\(i)@centegy.com", forKey: "email")
            user.setValue("Hamza\(i)", forKey: "pass")
            user.setValue("Hamza\(i)", forKey: "username")
        }
        
        do {
            try managedContext.save()
        }
        catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func retrievePressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            for data in result as! [NSManagedObject] {
                print(data.value(forKey: "username") as! String)
            }
        }
        catch {
            print("failed")
        }
        
    }
    
    @IBAction func updatePressed(_ sender: Any) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "username = %@", "Hamza5")
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            let objectUpdate = result[0] as! NSManagedObject
            objectUpdate.setValue("Mustafa@centegy.com", forKey: "email")
            objectUpdate.setValue("Mustafa", forKey: "pass")
            objectUpdate.setValue("Mustafa", forKey: "username")
            do{
                try managedContext.save()
            }
            catch {
                print(error)
            }
        }
        catch {
            print("failed")
        }
    }
    
    
    @IBAction func deletePressed(_ sender: Any) {
   
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "username = %@", "Hamza5")
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            
            if result != nil {
                for (index,values) in result.enumerated() {
                    let objectToDelete = result[index] as! NSManagedObject
                    managedContext.delete(objectToDelete)
                    
                    do{
                        try managedContext.save()
                    }
                    catch {
                        print(error)
                    }
                }
            }
        }
        catch {
            print(error)
        }
    }
}
